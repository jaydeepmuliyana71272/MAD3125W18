package com.example.macstudent.day1thunderstrom;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.AlertDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class ChangePasswordActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnStore;
    TextView chOldPwd,chPwd,chconfirPwd;
    DBHelper dbHelper;
    SQLiteDatabase thunderDB;
    String OldPwd,newpwd,confirmpwd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);

        btnStore = (Button) findViewById(R.id.btnStore);
        btnStore.setOnClickListener(this);

        chOldPwd = (TextView) findViewById(R.id.chOldPwd);
        chPwd = (TextView) findViewById(R.id.chPwd);
        chconfirPwd = (TextView) findViewById(R.id.chConPwd);

        dbHelper = new DBHelper(this);
        displayData();

    }

    @Override
    public void onClick(View view) {

        if (view.getId() == btnStore.getId()) {

            if(chPwd.length() != chconfirPwd.length())
            {
                Toast.makeText(this,"Not Match",Toast.LENGTH_LONG).show();

            }
            else {
                insertUser();

            }

            /*if (newpwd.equals(confirmpwd)) {
                insertUser();
            } else {

                    x1();
            }*/
        }
    }

   /* private  void x1(){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                this);

        // set title
        alertDialogBuilder.setTitle("Alert!!");

        // set dialog message
        alertDialogBuilder
                .setMessage("Both Password must be same!!!")
                .setCancelable(false)
                .setPositiveButton("Yes",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,int id) {
                        // if this button is clicked, close
                        // current activity
                        ChangePasswordActivity.this.finish();
                    }
                })
                .setNegativeButton("No",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,int id) {
                        // if this button is clicked, just close
                        // the dialog box and do nothing
                        dialog.cancel();
                    }
                });

        // create alert dialog
        AlertDialog alertDialog = alertDialogBuilder.create();

        // show it
        alertDialog.show();
    }
*/

    private void insertUser(){

        OldPwd = chOldPwd.getText().toString();
        newpwd = chPwd.getText().toString();
        confirmpwd = chconfirPwd.getText().toString();


        ContentValues cv = new ContentValues();
        cv.put("Password", newpwd);


        try{
            SharedPreferences sp = getSharedPreferences("com.jk.thunder.shared", Context.MODE_PRIVATE);
            String data = sp.getString("username","Data Missing");


            thunderDB = dbHelper.getWritableDatabase();

            thunderDB.update("UserInfo", cv, "Email=\""+data+"\"",null);

            Log.v("Update record","Successful");
            Toast.makeText(this,"Change Password Successfully",
                    Toast.LENGTH_LONG).show();

            Intent home1Intent = new Intent(getApplicationContext(),HomeActivity.class);
            startActivity(home1Intent);
            finish();


        }catch (Exception e){
            Log.e("Update User",e.getMessage());

        }
        thunderDB.close();
    }
    private void displayData(){

        try{

            SharedPreferences sp = getSharedPreferences("com.jk.thunder.shared", Context.MODE_PRIVATE);
            String data = sp.getString("username","Data Missing");

            thunderDB = dbHelper.getReadableDatabase();

            String columns[] = {"Password"};


            String query = "SELECT * FROM UserInfo where Email='" + data + "' ";
            Cursor cursor = thunderDB.rawQuery(query, null);



            while (cursor.moveToNext()){
                String password = cursor.getString
                        (cursor.getColumnIndex("Password"));
                chOldPwd.setText(password);

            }


        }catch (Exception e){
            Log.e("RegisterActivity : ",
                    "Unable to fetch the records");
        }

        thunderDB.close();

    }

}