package com.example.macstudent.day1thunderstrom;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ReciptActivity extends AppCompatActivity {

    @Override
    public void onBackPressed() {
finish();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipt);

        SharedPreferences sp = getSharedPreferences("com.example.macstudent.day1thunderstrom.shared", Context.MODE_PRIVATE);
        String data = "\n Car Plate: " + sp.getString("CarPlate","Data Missing");
        data += "\n Car Company:  " + sp.getString("Company", "Data Missing");
        data += "\n Payment Type: " + sp.getString("Payment", "Data Missing");
        data += "\n Lot No.: " + sp.getString("Lot", "Data Missing");
        data += "\n Spot No.: " + sp.getString("Spot", "Data Missing");
        data += "\n Time: " + sp.getString("DateTime", "Data Missing");
        data += "\n Total Amount: " + String.valueOf(sp.getInt("Amount", 0));

        TextView txtData = (TextView) findViewById(R.id.txt3);
        txtData.setText(data);
    }
}
