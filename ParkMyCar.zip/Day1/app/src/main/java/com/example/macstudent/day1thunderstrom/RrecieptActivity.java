package com.example.macstudent.day1thunderstrom;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

public class RrecieptActivity extends AppCompatActivity implements View.OnClickListener{

    TextView CPtxt,CCtxt,PTtxt,LNtxt,SNtxt,Timetxt,TAtxt;
    String number,company,time,slot,spot,amount,pay;

Button btn2;
    @Override
    public void onBackPressed() {

        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rreciept);



btn2 = (Button)findViewById(R.id.button2);
btn2.setOnClickListener(this);



        SharedPreferences sp = getSharedPreferences("com.example.macstudent.day1thunderstrom.shared", Context.MODE_PRIVATE);
        String data =   sp.getString("CarPlate","Data Missing");
      // Toast.makeText(this, data, Toast.LENGTH_SHORT).show();
        CPtxt = (TextView) findViewById(R.id.tt1);
        CPtxt.setText(data);
        number = data;

        //Toast.makeText(this, CPtxt.toString() , Toast.LENGTH_SHORT).show();

        String data1 =   sp.getString("Company", "Data Missing");
        CCtxt = (TextView) findViewById(R.id.tt2);
        CCtxt.setText(data1);
        company = data1;

        String data2 =  sp.getString("Payment", "Data Missing");
        PTtxt = (TextView) findViewById(R.id.tt3);
        PTtxt.setText(data2);
        pay = data2;

        String data3 =  sp.getString("Lot", "Data Missing");
        LNtxt = (TextView) findViewById(R.id.tt4);
        LNtxt.setText(data3);
        slot = data3;

        String data4 =  sp.getString("Spot", "Data Missing");
        SNtxt = (TextView) findViewById(R.id.tt5);
        SNtxt.setText(data4);
        spot = data4;

        String data5 =  sp.getString("DateTime", "Data Missing");
        Timetxt = (TextView) findViewById(R.id.tt6);
        Timetxt.setText(data5);
        time = data5;

        String data6 =  String.valueOf(sp.getInt("Amount", 0));
        TAtxt = (TextView) findViewById(R.id.tt7);
        TAtxt.setText(data6);
        amount = data6;

    }

    @Override
    public void onClick(View v) {
        if(v.getId() == btn2.getId())
        {
            makemail();
        }
    }

    private void makemail() {
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setType("text/plain");

        emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{"abhipatel4592@gmail.com"});
        emailIntent.putExtra(Intent.EXTRA_SUBJECT,"Parking Receipt");
        emailIntent.putExtra(Intent.EXTRA_TEXT,"Car Number:"+number+"\nCar Company:"+company+"\nTime:"+time+"\nSlot No.:"+slot+"\nSpot No.:"+spot+"\nTotal Amount:"+amount+"\nPayment Type:"+pay);

        emailIntent.setType("message/rfc822");
        startActivity(Intent.createChooser(emailIntent,"select email client"));
    }
}
