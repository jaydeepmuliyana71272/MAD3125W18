package com.example.macstudent.day1thunderstrom;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by HP on 4/18/2018.
 */

public class splash {

    SharedPreferences pref;
    SharedPreferences.Editor editor;
    Context context;

    public splash(Context context)
    {
        this.context = context;
        pref = context.getSharedPreferences("First",0);
        editor = pref.edit();

    }

    public void setFirst(Boolean isFirst)
    {
        editor.putBoolean("check",isFirst);
        editor.commit();
    }

    public boolean Check()
    {
        return pref.getBoolean("check",true);
        
    }

}
