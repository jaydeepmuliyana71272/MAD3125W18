package com.example.macstudent.day1thunderstrom;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.SharedPreferences;
import android.content.*;

import java.util.jar.Attributes;


public class UpdateActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnUpdate;
    EditText upName,upEmail,upPhone;
    TextView uppwd;
    DBHelper dbHelper;
    SQLiteDatabase thunderDB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        btnUpdate = (Button) findViewById(R.id.btnupdate);
        btnUpdate.setOnClickListener(this);

        uppwd = (TextView) findViewById(R.id.uppwd);
        uppwd.setOnClickListener(this);

        upName = (EditText) findViewById(R.id.upName);
        upEmail = (EditText) findViewById(R.id.upEmail);
        upPhone = (EditText) findViewById(R.id.upPhone);

        dbHelper = new DBHelper(this);
        displayData();
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == btnUpdate.getId()) {

            insertUser();


        } else if (view.getId() == uppwd.getId()) {

            Intent changepwdIntent = new Intent
                    (this, ChangePasswordActivity.class);
            startActivity(changepwdIntent);
            finish();

        }

    }

    private void insertUser(){

        String name = upName.getText().toString();
        String phone = upPhone.getText().toString();
        String email = upEmail.getText().toString();

        ContentValues cv = new ContentValues();
        cv.put("Name", name);
        cv.put("Phone", phone);
        cv.put("Email", email);


        try{
            SharedPreferences sp = getSharedPreferences("com.jk.thunder.shared", Context.MODE_PRIVATE);
            String data = sp.getString("username","Data Missing");


            thunderDB = dbHelper.getWritableDatabase();

            thunderDB.update("UserInfo", cv, "Email=\""+data+"\"",null);

            Log.v("Insert record","Successful");

            Toast.makeText(this,"Update Profile Successfully",
                    Toast.LENGTH_LONG).show();

        }catch (Exception e){
            Log.e("Insert User",e.getMessage());

        }
        thunderDB.close();
    }


    private void displayData(){

        try{

            SharedPreferences sp = getSharedPreferences("com.jk.thunder.shared", Context.MODE_PRIVATE);
            String data = sp.getString("username","Data Missing");

            thunderDB = dbHelper.getReadableDatabase();

            String columns[] = {"Name", "Phone",
                    "Email"};


            String query = "SELECT * FROM UserInfo where Email='" + data + "' ";
            Cursor cursor = thunderDB.rawQuery(query, null);



            while (cursor.moveToNext()){
                String name = cursor.getString
                        (cursor.getColumnIndex("Name"));
                upName.setText(name);

                String email = cursor.getString(
                        cursor.getColumnIndex("Email")
                );
                upEmail.setText(email);

                String phone = cursor.getString(
                        cursor.getColumnIndex("Phone")
                );
                upPhone.setText(phone);

                String userInfo = name + "\n" + phone + "\n"+
                        email + "\n" ;



               // Toast.makeText(this,userInfo,
              //          Toast.LENGTH_LONG).show();


            }


        }catch (Exception e){
            Log.e("RegisterActivity : ",
                    "Unable to fetch the records");
        }

        thunderDB.close();

    }
}