package com.example.macstudent.day1thunderstrom;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class SupportActivity extends AppCompatActivity implements OnClickListener {

    Button btn1,btn2,btn3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_support);

        btn1 = (Button)findViewById(R.id.btncall);
        btn1.setOnClickListener(this);
        btn2 = (Button)findViewById(R.id.btnsms);
        btn2.setOnClickListener(this);
        btn3 =  (Button)findViewById(R.id.btnemail);
        btn3.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch(view.getId())
        {
            case R.id.btncall: makeCall();
            break;

            case R.id.btnsms: makeMsg();
            break;

            case R.id.btnemail: makeemail();
            break;


        }


    }

    private void makeMsg() {
        Intent smsItent = new Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:4377782213"));
        smsItent.putExtra("sms_body","test message");

        if(ActivityCompat.checkSelfPermission(getApplicationContext(),Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED){
            Toast.makeText(getApplicationContext(),"sms permission denied",Toast.LENGTH_LONG).show();
            return;

        }
        startActivity(smsItent);
    }

    private void makeemail() {
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setType("text/plain");

        emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{"abhipatel4592@gmail.com"});
        emailIntent.putExtra(Intent.EXTRA_SUBJECT,"test email");
        emailIntent.putExtra(Intent.EXTRA_TEXT,"this is a text message");
        emailIntent.setType("message/rfc822");
        startActivity(Intent.createChooser(emailIntent,"select email client"));
    }

    private void makeCall() {
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:4377782213"));


        if(ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED)
        {
            Toast.makeText(getApplicationContext(),"Call Permission Deined", Toast.LENGTH_SHORT).show();
            return;
        }
        startActivity(callIntent);
    }


}
