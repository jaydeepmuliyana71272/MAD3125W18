package com.example.jaydeep.app1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class PArkingActivity extends AppCompatActivity implements View.OnClickListener,AdapterView,AdapterView.OnItemSelectedListener{

    RadioButton rd1,rd2,rd3;
    TextView txtAmt;
    int parkingRate[] = {10,20,35};
    Spinner spinLot, spinSpot,spinPayment,spinCompany;
    String lot, spot, carPlate,payment,dateTime,company;
    int amount;
    String lots[] = {"A","B"};
    String spots[] = {"1","2"};
    String PaymentMethod[] = {"DEBIT","CREDIT"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parking);

        rd1 = (RadioButton)findViewById(R.id.radioButton);
        rd1.setOnClickListener(this);

        rd2 = (RadioButton)findViewById(R.id.radioButton2);
        rd2.setOnClickListener(this);

        rd3 = (RadioButton)findViewById(R.id.radioButton3);
        rd3.setOnClickListener(this);

        txtAmt = (TextView)findViewById(R.id.txtAmount);
        txtAmt.setText("$" + String.valueOf(parkingRate[0]));



    }

    @Override
    public void onClick(View v) {

        if(rd1.isChecked())
        {
            txtAmt.setText("$" +String.valueOf(parkingRate[0] ));
        }
        else if(rd2.isChecked())
        {
            txtAmt.setText("$" +String.valueOf(parkingRate[1] ));
        }
        else if (rd3.isChecked())
        {
            txtAmt.setText("$" +String.valueOf(parkingRate[1] ));
        }

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
    {
        if(adapterView.getId() == spinLot.getId())
        {
            Toast.makeText(this,lots[position],Toast.LENGTH_LONG).show();
            lot = lots[position];

        }
        else  if(adapterView.getId() == spinSpot.getId())
        {
            Toast.makeText(this,lots[position],Toast.LENGTH_LONG).show();
            spot = spots[position];

        }
        else  if(adapterView.getId() == spinPayment.getId())
        {
            Toast.makeText(this,lots[position],Toast.LENGTH_LONG).show();
            payment = PaymentMethod[position];

        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
