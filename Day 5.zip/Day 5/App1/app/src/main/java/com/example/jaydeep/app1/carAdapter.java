package com.example.jaydeep.app1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class carAdapter extends BaseAdapter {

    Context context;
    int logos[];
    String[] companyNamrs;
    LayoutInflater inflater;

    carAdapter(Context)

    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        view = inflater.inflate(R.layout.car,null);
        ImageView carLogo = (ImageView) view.findView
        return null;
    }
}
