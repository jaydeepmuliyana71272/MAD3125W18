package com.example.jaydeep.app1;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

import java.util.Calendar;

public class RegistrationActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnRegi;
    EditText edtBday;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);


        edtBday = (EditText) findViewById(R.id.edtBday);
        btnRegi = (Button) findViewById(R.id.btnReg);
        btnRegi.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if (v.getId() == btnRegi.getId())
        {
            Intent btnNext = new Intent(RegistrationActivity.this,PArkingActivity.class);
            startActivity(btnNext);
        }
        else if(v.getId() == edtBday.getId())
        {
           Calendar calendar = Calendar.getInstance();
           new DatePickerDialog(this,datePickerListener,calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH)).show();
        }
    }

    DatePickerDialog.OnDateSetListener datePickerListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int month, int day) {
            String yy = String.valueOf(year);
            String mm = String.valueOf(month+1);
            String dd = String.valueOf(day);

            if(month < 10)
            {
                mm = "0" + mm;
            }
            if(day < 10)
            {
                dd = "0" + dd;

            }
            edtBday.setText(dd+"/"+mm+"/"+yy);


        }
    };
}
