package com.example.jaydeep.app1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnReg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnReg = (Button) findViewById(R.id.btnReg);
        btnReg.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if(v.getId() == btnReg.getId())
        {
            Intent Reg = new Intent(MainActivity.this,RegistrationActivity.class);
            startActivity(Reg);

        }
    }
}
